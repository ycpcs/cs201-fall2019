package edu.ycp.cs201.exam02;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q9Test {
	private static class NaturalComparator<E extends Comparable<E>> implements Comparator<E> {
		@Override
		public int compare(E left, E right) {
			return left.compareTo(right);
		}
	}
	
	private static class CaseInsensitiveStringComparator implements Comparator<String> {
		@Override
		public int compare(String left, String right) {
			return left.toLowerCase().compareTo(right.toLowerCase());
		}
	}
	
	private List<Integer> numbers;
	private List<String> letters;
	
	@Before
	public void setUp() {
		numbers = Arrays.asList(58, 51, 44, 76, 27, 93, 16, 43, 66, 52, 62, 53, 3, 0, 82, 17, 49, 7, 74, 37);
		letters = Arrays.asList("N", "f", "G", "Y", "T", "B", "u", "w", "s", "O", "C", "z", "K", "A", "V", "J", "m", "R", "E", "H");
	}
	
	@Test
	public void testNumbersBetween48And91() throws Exception {
		int count = Q9.countBetween(numbers, (Integer)48, (Integer)91, new NaturalComparator<Integer>());
		assertEquals(10, count);
	}
	
	@Test
	public void testNumbersBetween12And33() throws Exception {
		int count = Q9.countBetween(numbers, (Integer)12, (Integer)33, new NaturalComparator<Integer>());
		assertEquals(3, count);
	}
	
	@Test
	public void testNumbersInEmptyRange() throws Exception {
		int count = Q9.countBetween(numbers, (Integer)43, (Integer)42, new NaturalComparator<Integer>());
		assertEquals(0, count);
	}
	
	@Test
	public void testNumbersCountAll() throws Exception {
		int count = Q9.countBetween(numbers, (Integer)0, (Integer)93, new NaturalComparator<Integer>());
		assertEquals(20, count);
	}
	
	@Test
	public void testLetters_G_to_N() throws Exception {
		int count = Q9.countBetween(letters, "G", "N", new NaturalComparator<>());
		assertEquals(5, count);
	}
	
	@Test
	public void testLetters_g_to_n() throws Exception {
		int count = Q9.countBetween(letters, "g", "n", new NaturalComparator<>());
		assertEquals(1, count);
	}
	
	@Test
	public void testLetters_G_to_N_caseInsensitive() throws Exception {
		int count = Q9.countBetween(letters, "G", "N", new CaseInsensitiveStringComparator());
		assertEquals(6, count);
	}
	
	@Test
	public void testLetters_C_to_Y_caseInsensitive() throws Exception {
		int count = Q9.countBetween(letters, "C", "Y", new CaseInsensitiveStringComparator());
		assertEquals(17, count);
	}
}
