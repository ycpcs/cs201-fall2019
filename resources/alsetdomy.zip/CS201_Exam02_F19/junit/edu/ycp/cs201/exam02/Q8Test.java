package edu.ycp.cs201.exam02;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;

public class Q8Test {
	private List<Integer> numbers;
	private Set<String> names;
	
	@Before
	public void setUp() {
		numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
		names = new TreeSet<String>();
		names.addAll(Arrays.asList(
				"Anika", 
				"Augustina", 
				"Azzie", 
				"Cristy",
				"Kathyrn", 
				"Leandra", 
				"Mabel", 
				"Roxie", 
				"Takisha", 
				"Verdell"
				));
	}
	
	@Test
	public void testNumbersEvery2() throws Exception {
		List<Integer> result = new ArrayList<Integer>();
		Q8.copyEveryNth(numbers, result, 2);
		assertEquals(7, result.size());
		assertEquals((Integer)2, result.get(0));
		assertEquals((Integer)4, result.get(1));
		assertEquals((Integer)6, result.get(2));
		assertEquals((Integer)8, result.get(3));
		assertEquals((Integer)10, result.get(4));
		assertEquals((Integer)12, result.get(5));
		assertEquals((Integer)14, result.get(6));
	}
	
	@Test
	public void testNumbersEvery3() throws Exception {
		List<Integer> result = new ArrayList<Integer>();
		Q8.copyEveryNth(numbers, result, 3);
		assertEquals(5, result.size());
		assertEquals((Integer)3, result.get(0));
		assertEquals((Integer)6, result.get(1));
		assertEquals((Integer)9, result.get(2));
		assertEquals((Integer)12, result.get(3));
		assertEquals((Integer)15, result.get(4));
	}
	
	@Test
	public void testNumbersEvery7() throws Exception {
		List<Integer> result = new ArrayList<Integer>();
		Q8.copyEveryNth(numbers, result, 7);
		assertEquals(2, result.size());
		assertEquals((Integer)7, result.get(0));
		assertEquals((Integer)14, result.get(1));
	}
	
	@Test
	public void testNamesEvery2() throws Exception {
		List<String> result = new ArrayList<String>();
		Q8.copyEveryNth(names, result, 2);
		assertEquals(5, result.size());
		assertEquals("Augustina", result.get(0));
		assertEquals("Cristy", result.get(1));
		assertEquals("Leandra", result.get(2));
		assertEquals("Roxie", result.get(3));
		assertEquals("Verdell", result.get(4));
	}
	
	@Test
	public void testNamesEvery3() throws Exception {
		List<String> result = new ArrayList<String>();
		Q8.copyEveryNth(names, result, 3);
		assertEquals(3, result.size());
		assertEquals("Azzie", result.get(0));
		assertEquals("Leandra", result.get(1));
		assertEquals("Takisha", result.get(2));
	}
	
	@Test
	public void testNamesEvery4() throws Exception {
		List<String> result = new ArrayList<String>();
		Q8.copyEveryNth(names, result, 4);
		assertEquals(2, result.size());
		assertEquals("Cristy", result.get(0));
		assertEquals("Roxie", result.get(1));
	}
	
	@Test
	public void testNamesEvery9() throws Exception {
		List<String> result = new ArrayList<String>();
		Q8.copyEveryNth(names, result, 9);
		assertEquals(1, result.size());
		assertEquals("Takisha", result.get(0));
	}
}
