package edu.ycp.cs201.exam02;

import java.util.Collection;

public class Q8 {
	public static<E> void copyEveryNth(Collection<E> source, Collection<E> dest, int n) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
