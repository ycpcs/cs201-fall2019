package edu.ycp.cs201.exam02;

import java.util.Comparator;
import java.util.List;

public class Q9 {
	public static<E> int countBetween(List<E> list, E low, E high, Comparator<E> comp) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
