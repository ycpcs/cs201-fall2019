package edu.ycp.cs201.exam01;

public abstract class Function {
	public abstract double apply(double x);
}
