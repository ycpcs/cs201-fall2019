package edu.ycp.cs201.exam01;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class PlotGUI extends JPanel {
	private static final int TEXT_FIELD_W = 5;

	private static final long serialVersionUID = 1L;
	
	private static final Font TEXT_FIELD_FONT =
			new Font(Font.DIALOG, 0, 20);
	
	private PlotPanel plotPanel;
	private JCheckBox isSineFunction;
	private JTextField xminField;
	private JTextField xmaxField;
	private JTextField yminField;
	private JTextField ymaxField;
	private JTextField param1Field;
	private JTextField param2Field;
	private JTextField param3Field;
	private JButton plotButton;
	
	public PlotGUI() {
		setLayout(new FlowLayout());
		setPreferredSize(new Dimension(1000, 660));
		plotPanel = addComponent(new PlotPanel());
		isSineFunction = addComponent(new JCheckBox());
		xminField = addComponent(textField());
		xmaxField = addComponent(textField());
		yminField = addComponent(textField());
		ymaxField = addComponent(textField());
		param1Field = addComponent(textField());
		param2Field = addComponent(textField());
		param3Field = addComponent(textField());
		plotButton = addComponent(new JButton("Plot!"));
		plotButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handlePlotButtonClicked(e);
			}
		});
	}

	protected void handlePlotButtonClicked(ActionEvent e) {
		boolean isSine = isChecked(isSineFunction);
		double xmin = parseValue(xminField);
		double xmax = parseValue(xmaxField);
		double ymin = parseValue(yminField);
		double ymax = parseValue(ymaxField);
		double p1 = parseValue(param1Field);
		double p2 = parseValue(param2Field);
		double p3 = parseValue(param3Field);
		Function func;
		if (isSine) {
			func = new SineFunction(p1, p2, p3);
		} else {
			func = new LineFunction(p1, p2);
		}
		plotPanel.setXmin(xmin);
		plotPanel.setXmax(xmax);
		plotPanel.setYmin(ymin);
		plotPanel.setYmax(ymax);
		plotPanel.setFunction(func);
		repaint();
	}

	private boolean isChecked(JCheckBox cb) {
		return cb.isSelected();
	}

	private double parseValue(JTextField tf) {
		String text = tf.getText().trim();
		try {
			return Double.valueOf(text);
		} catch (NumberFormatException e) {
			return 0.0;
		}
	}

	private<E extends JComponent> E addComponent(E comp) {
		add(comp);
		return comp;
	}
	
	private JTextField textField() {
		JTextField tf = new JTextField(TEXT_FIELD_W);
		tf.setFont(TEXT_FIELD_FONT);
		return tf;
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				PlotGUI gui = new PlotGUI();
				JFrame frame = new JFrame("Function plot!");
				frame.setContentPane(gui);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}
