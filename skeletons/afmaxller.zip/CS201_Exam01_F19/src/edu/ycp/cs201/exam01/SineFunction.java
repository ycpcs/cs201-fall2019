package edu.ycp.cs201.exam01;

public class SineFunction extends Function {
	// TODO: add any necessary field(s)

	public SineFunction(double a, double q, double b) {
		// TODO: implement
	}
	
	// TODO: add any necessary method(s)
}
