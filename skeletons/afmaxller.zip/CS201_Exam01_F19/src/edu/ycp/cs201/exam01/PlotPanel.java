package edu.ycp.cs201.exam01;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class PlotPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private Function func;
	private double xmin, xmax;
	private double ymin, ymax;
	
	public PlotPanel() {
		setPreferredSize(new Dimension(1000, 600));
		setBackground(Color.WHITE);
	}
	
	public void setFunction(Function func) {
		this.func = func;
	}
	
	public void setXmin(double xmin) {
		this.xmin = xmin;
	}
	
	public void setXmax(double xmax) {
		this.xmax = xmax;
	}
	
	public void setYmin(double ymin) {
		this.ymin = ymin;
	}
	
	public void setYmax(double ymax) {
		this.ymax = ymax;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g); // paint background
		
		// Draws the x axis
		g.setColor(Color.DARK_GRAY);
		g.drawLine(0, 300, 1000, 300);
		
		if (func == null) {
			return;
		}
		
		// This will make lines drawn black and 3 pixels thick
		g.setColor(Color.BLACK);
		((Graphics2D) g).setStroke(new BasicStroke(3));
		
		// TODO: plot the function from xmin..xmax.
		//
		// You can assume that the drawing surface is
		// 1000 pixels by 600 pixels.
		//
		// Note that ymin is the y value corresponding
		// to the bottom row of pixels, and ymax is the y value
		// corresponding to the top row of pixels.
		
	}
	
	// TODO: you may add additional methods if desired
}
