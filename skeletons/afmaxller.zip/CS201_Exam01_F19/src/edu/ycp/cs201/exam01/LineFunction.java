package edu.ycp.cs201.exam01;

public class LineFunction extends Function {
	// TODO: add any necessary field(s)

	public LineFunction(double m, double b) {
		// TODO: implement
	}
	
	// TODO: add any necessary method(s)
}
