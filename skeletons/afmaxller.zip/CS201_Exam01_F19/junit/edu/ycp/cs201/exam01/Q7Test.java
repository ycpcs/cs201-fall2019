package edu.ycp.cs201.exam01;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Q7Test {
	private final double DELTA = 0.000001;
	
	private LineFunction line1;
	private LineFunction line2;
	private SineFunction sin1;
	private SineFunction sin2;
	
	@Before
	public void setUp() {
		line1 = new LineFunction(3.4, 2.0);
		line2 = new LineFunction(-8.1, 1.1);
		sin1 = new SineFunction(4.4, 2.1, -10.33);
		sin2 = new SineFunction(1.0, -4.01, 5.7);
	}
	
	@Test
	public void testLineFunctionApply() throws Exception {
		assertEquals(3.4*0.0 + 2.0, line1.apply(0.0), DELTA);
		assertEquals(3.4*6.9 + 2.0, line1.apply(6.9), DELTA);
		assertEquals(3.4*-18.11 + 2.0, line1.apply(-18.11), DELTA);
		assertEquals(-8.1*0.0 + 1.1, line2.apply(0.0), DELTA);
		assertEquals(-8.1*6.9 + 1.1, line2.apply(6.9), DELTA);
		assertEquals(-8.1*-18.11 + 1.1, line2.apply(-18.11), DELTA);
	}
	
	@Test
	public void testSineFunctionApply() throws Exception {
		assertEquals(-10.33, sin1.apply(0.0), DELTA);
		assertEquals(-6.20105102343, sin1.apply(6.9), DELTA);
		assertEquals(-11.7636463949, sin1.apply(-18.11), DELTA);
		assertEquals(5.7, sin2.apply(0.0), DELTA);
		assertEquals(5.13096333655, sin2.apply(6.9), DELTA);
		assertEquals(5.34354680597, sin2.apply(-18.11), DELTA);
	}
}
