package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q11Test {
	@Test
	public void testCountDigitOccurrences1() throws Exception {
		assertEquals(1, Q11.countDigitOccurrences(239875, 2));
	}
	
	@Test
	public void testCountDigitOccurrences2() throws Exception {
		assertEquals(1, Q11.countDigitOccurrences(239875, 9));
	}
	
	@Test
	public void testCountDigitOccurrences3() throws Exception {
		assertEquals(0, Q11.countDigitOccurrences(239875, 4));
	}
	
	@Test
	public void testCountDigitOccurrences4() throws Exception {
		assertEquals(4, Q11.countDigitOccurrences(39393934, 3));
	}
	
	@Test
	public void testCountDigitOccurrences5() throws Exception {
		assertEquals(3, Q11.countDigitOccurrences(39393934, 9));
	}
	
	@Test
	public void testCountDigitOccurrences6() throws Exception {
		assertEquals(1, Q11.countDigitOccurrences(39393934, 4));
	}
	
	@Test
	public void testCountDigitOccurrences7() throws Exception {
		assertEquals(0, Q11.countDigitOccurrences(39393934, 6));
	}
	
	@Test
	public void testCountDigitOccurrences8() throws Exception {
		assertEquals(6, Q11.countDigitOccurrences(1000000, 0));
	}
	
	@Test
	public void testCountDigitOccurrences9() throws Exception {
		assertEquals(1, Q11.countDigitOccurrences(1000000, 1));
	}
	
	@Test
	public void testCountDigitOccurrences10() throws Exception {
		assertEquals(0, Q11.countDigitOccurrences(1000000, 2));
	}
	
	@Test
	public void testCountDigitOccurrences11() throws Exception {
		assertEquals(1, Q11.countDigitOccurrences(0, 0));
	}
}
