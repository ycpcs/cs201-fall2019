package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Q9Test {
	private static final double DELTA = 0.00001;
	
	private Calculator calc;
	
	@Before
	public void setUp() {
		calc = new Calculator();
	}
	
	@Test
	public void testInitiallyZero() throws Exception {
		assertEquals(0.0, calc.getValue(), DELTA);
	}
	
	@Test
	public void testAdd() throws Exception {
		calc.add(4.5);
		assertEquals(4.5, calc.getValue(), DELTA);
		calc.add(-2.1);
		assertEquals(4.5-2.1, calc.getValue(), DELTA);
		calc.add(0.3);
		assertEquals(4.5-2.1+0.3, calc.getValue(), DELTA);
	}
	
	@Test
	public void testSubtract() throws Exception {
		calc.subtract(3.2);
		assertEquals(-3.2, calc.getValue(), DELTA);
		calc.subtract(-4.9);
		assertEquals(-3.2+4.9, calc.getValue(), DELTA);
		calc.subtract(1.0);
		assertEquals(-3.2+4.9-1.0, calc.getValue(), DELTA);
	}
	
	@Test
	public void testMultiply() throws Exception {
		calc.multiply(5.0);
		assertEquals(0.0, calc.getValue(), DELTA);
		calc.add(1.0); // need to set a non-zero value before multiply has any effect
		calc.multiply(4.3);
		assertEquals(4.3, calc.getValue(), DELTA);
		calc.multiply(-6.7);
		assertEquals(4.3*-6.7, calc.getValue(), DELTA);
	}
	
	@Test
	public void testDivide() throws Exception {
		calc.divide(5.0);
		assertEquals(0.0, calc.getValue(), DELTA);
		calc.add(10.0); // need to set a non-zero value before divide has any effect
		calc.divide(4.0);
		assertEquals(10.0/4.0, calc.getValue(), DELTA);
		calc.divide(-3.3);
		assertEquals(10.0/4.0/-3.3, calc.getValue(), DELTA);
	}
	
	@Test
	public void testMix() throws Exception {
		calc.add(2.2);
		calc.subtract(3.3);
		calc.multiply(-4.4);
		calc.divide(5.5);
		assertEquals(((2.2-3.3)*-4.4)/5.5, calc.getValue(), DELTA);
	}
}
