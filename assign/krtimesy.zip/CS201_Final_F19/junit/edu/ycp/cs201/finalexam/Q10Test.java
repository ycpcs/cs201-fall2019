package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

public class Q10Test {
	private Map<String, Integer> exampleMap1;
	private Map<String, Integer> exampleMap2;
	private Map<String, Integer> exampleMap3;
	
	@Before
	public void setUp() {
		exampleMap1 = new HashMap<String, Integer>();
		exampleMap1.put("A", 1);
		exampleMap1.put("B", 2);
		exampleMap1.put("C", 3);
		
		exampleMap2 = new TreeMap<String, Integer>();
		exampleMap2.put("spam", 6);
		exampleMap2.put("eggs", 2);
		exampleMap2.put("baked beans", 1);
		exampleMap2.put("lobster thermidor", 1);
		
		exampleMap3 = new HashMap<String, Integer>();
		exampleMap3.put("red", 50);
		exampleMap3.put("green", 0); // tricky!
		exampleMap3.put("blue", 4);
		exampleMap3.put("purple", 11);
	}
	
	public static int countOf(List<String> list, String s) {
		int count = 0;
		for (String elt : list) {
			if (elt.equals(s)) {
				count++;
			}
		}
		return count;
	}
	
	@Test
	public void testExampleMap1() throws Exception {
		List<String> expanded = Q10.expand(exampleMap1);
		assertEquals(6, expanded.size());
		assertEquals(1, countOf(expanded, "A"));
		assertEquals(2, countOf(expanded, "B"));
		assertEquals(3, countOf(expanded, "C"));
	}
	
	@Test
	public void testExampleMap2() throws Exception {
		List<String> expanded = Q10.expand(exampleMap2);
		assertEquals(10, expanded.size());
		assertEquals(6, countOf(expanded, "spam"));
		assertEquals(2, countOf(expanded, "eggs"));
		assertEquals(1, countOf(expanded, "baked beans"));
		assertEquals(1, countOf(expanded, "lobster thermidor"));
	}
	
	@Test
	public void testExampleMap3() throws Exception {
		List<String> expanded = Q10.expand(exampleMap3);
		assertEquals(65, expanded.size());
		assertEquals(50, countOf(expanded, "red"));
		assertEquals(0, countOf(expanded, "green"));
		assertEquals(4, countOf(expanded, "blue"));
		assertEquals(11, countOf(expanded, "purple"));
	}
}
