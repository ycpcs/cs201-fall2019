package edu.ycp.cs201.finalexam;

public class Calculator {
	// TODO: add fields, a constructor, and methods
	
	// Look at the code in Q9Test to see how the constructor
	// and methods are meant to work
}
