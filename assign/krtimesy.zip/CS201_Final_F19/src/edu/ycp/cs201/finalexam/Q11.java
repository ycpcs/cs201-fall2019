package edu.ycp.cs201.finalexam;

public class Q11 {
	// IMPORTANT: your solution MUST be recursive.
	// A non-recursive solution will not receive any credit.
	public static int countDigitOccurrences(int n, int digit) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
