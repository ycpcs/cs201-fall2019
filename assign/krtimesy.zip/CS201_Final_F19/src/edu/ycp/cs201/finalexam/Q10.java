package edu.ycp.cs201.finalexam;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Q10 {
	public static List<String> expand(Map<String, Integer> map) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
