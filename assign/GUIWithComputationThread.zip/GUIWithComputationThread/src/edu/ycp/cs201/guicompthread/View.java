package edu.ycp.cs201.guicompthread;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class View extends JPanel {
	private static final long serialVersionUID = 1L;

	// This is the region currently selected by the user.
	private Region region;
	
	// This BufferedImage contains the results of the most recent rendering.
	private BufferedImage img;
	
	// This field is set to true while rendering is underway.
	private boolean rendering;
	
	public View() {
		setBackground(Color.GRAY);
		setPreferredSize(new Dimension(600, 600));
		
		region = new Region();
		
		img = new BufferedImage(Model.WIDTH, Model.HEIGHT, BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, Model.WIDTH, Model.HEIGHT);
		g.dispose();
		
		MouseAdapter listener = new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				handleMousePressed(e);
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				handleMouseDragged(e);
			}
			
			@Override
			public void mouseReleased(MouseEvent e) {
				handleMouseReleased(e);
			}
		};
		
		addMouseListener(listener);
		addMouseMotionListener(listener);
	}
	
	protected void handleMousePressed(MouseEvent e) {
		if (rendering) {
			// Region cannot be selected while rendering
			return;
		}
		region.setStart(e.getX(), e.getY());
		repaint();
	}

	protected void handleMouseDragged(MouseEvent e) {
		if (rendering) {
			// Region cannot be selected while rendering
			return;
		}
		region.setEnd(e.getX(), e.getY());
		repaint();
	}

	protected void handleMouseReleased(MouseEvent e) {
		if (rendering) {
			// Region cannot be selected while rendering
			return;
		}
		region.setEnd(e.getX(), e.getY());
		startComputation();
		repaint();
	}

	private void startComputation() {
		ComputeAndRender task = new ComputeAndRender(this, region.clone());
		Thread t = new Thread(task);
		t.start();
		
		region.reset();
		rendering = true;
	}

	// This method is called by the ComputeAndRender task
	// when the computation and rendering are complete.
	public void computationFinished(BufferedImage img) {
		this.img = img;
		rendering = false;
		repaint();
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		// Draw the most recent rendering
		g.drawImage(img, 0, 0, Model.WIDTH, Model.HEIGHT, null);
		
		// Draw mouse drag region
		if (region.getWidth() > 0) {
			g.setColor(Color.YELLOW);
			g.drawRect(region.getMinX(), region.getMinY(), region.getWidth(), region.getHeight());
		}
		
		if (rendering) {
			g.setColor(Color.PINK);
			Font f = new Font("Dialog", Font.BOLD, 44);
			g.setFont(f);
			g.drawString("Rendering...", 40, 200);
		}
	}
}
