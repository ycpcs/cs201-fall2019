package edu.ycp.cs201.exam03;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q8Test {
	@Test
	public void testRedact1() throws Exception {
		assertEquals("XXXX is fun, XXXX is awesome", Q8.redact("Java is fun, Java is awesome", "Java"));
	}
	
	@Test
	public void testRedact2() throws Exception {
		assertEquals("Sit on a XXXXXX pan, Otis", Q8.redact("Sit on a potato pan, Otis", "potato"));
	}
	
	@Test
	public void testRedact3() throws Exception {
		assertEquals("Sit on a potato pan, XXXX", Q8.redact("Sit on a potato pan, Otis", "Otis"));
	}
	
	@Test
	public void testRedact4() throws Exception {
		assertEquals("XXXX bong XXXX bong XXXX bong", Q8.redact("bing bong bing bong bing bong", "bing"));
	}
	
	@Test
	public void testRedact5() throws Exception {
		assertEquals("bing XXXX bing XXXX bing XXXX", Q8.redact("bing bong bing bong bing bong", "bong"));
	}
	
	@Test
	public void testRedact6() throws Exception {
		assertEquals("XXnanana XXnaXXna XXnana", Q8.redact("bananana banabana banana", "ba"));
	}
	
	@Test
	public void testRedact7() throws Exception {
		assertEquals("XXXXnana XXXXXXXX XXXXna", Q8.redact("bananana banabana banana", "bana"));
	}
	
	@Test
	public void testRedact8() throws Exception {
		assertEquals("XXXXXXna banabana XXXXXX", Q8.redact("bananana banabana banana", "banana"));
	}
	
	@Test
	public void testRedact9() throws Exception {
		assertEquals("A smell of petroleum prevails throughout", Q8.redact("A smell of petroleum prevails throughout", "spam"));
	}
	
	@Test
	public void testRedact10() throws Exception {
		assertEquals("", Q8.redact("", "spam"));
	}
}
