package edu.ycp.cs201.exam03;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class Q9Test {
	private List<String> food;
	private List<String> colors;
	
	@Before
	public void setUp() {
		food = Arrays.asList("Ham", "Eggs", "Beans", "Ham", "Beans", "Ham");
		colors = Arrays.asList(
				"Red", "Green", "Blue", "Blue", "Red",
				"Purple", "Orange", "Red", "Yellow",
				"Red", "Puce", "Blue", "Yellow");
	}
	
	@Test
	public void testCondense1() throws Exception {
		Map<String, Integer> result = Q9.condense(food);
		assertEquals(3, result.size());
		assertEquals((Integer)3, result.get("Ham"));
		assertEquals((Integer)1, result.get("Eggs"));
		assertEquals((Integer)2, result.get("Beans"));
	}
	
	@Test
	public void testCondense2() throws Exception {
		Map<String, Integer> result = Q9.condense(colors);
		assertEquals(7, result.size());
		assertEquals((Integer)4, result.get("Red"));
		assertEquals((Integer)1, result.get("Green"));
		assertEquals((Integer)3, result.get("Blue"));
		assertEquals((Integer)1, result.get("Purple"));
		assertEquals((Integer)1, result.get("Orange"));
		assertEquals((Integer)2, result.get("Yellow"));
		assertEquals((Integer)1, result.get("Puce"));
	}
}
