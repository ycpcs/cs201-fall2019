package edu.ycp.cs201.exam03;

public class Q8 {
	// You can call this method to get a String containing a
	// specified number of 'X' characters.
	private static String xString(int len) {
		StringBuilder buf = new StringBuilder();
		for (int i = 0; i < len; i++) {
			buf.append('X');
		}
		return buf.toString();
	}
	
	// IMPORTANT: your solution **must** be recursive.
	// Do not use a loop.  Non-recursive solutions
	// will not receive any credit.
	public static String redact(String s, String word) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
