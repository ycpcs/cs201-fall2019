package edu.ycp.cs201.exam03;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Q9 {
	public static Map<String, Integer> condense(List<String> coll) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
